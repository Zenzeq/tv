//
//  UITextField+Range.h
//  FLEX
//
//  Created by Tanner on 6/13/17.
//

#import <UIKit/UIKit.h>

@interface UITextField (Range)

@property (nonatomic, readonly) NSRange flex_selectedRange;

@end
