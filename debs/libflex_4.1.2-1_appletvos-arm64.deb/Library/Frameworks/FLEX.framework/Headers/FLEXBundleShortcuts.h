//
//  FLEXBundleShortcuts.h
//  FLEX
//
//  Created by Tanner Bennett on 12/12/19.
//  Copyright © 2020 FLEX Team. All rights reserved.
//

#import "FLEXShortcutsSection.h"

NS_ASSUME_NONNULL_BEGIN

/// Provides a "Browse Bundle Directory" action
@interface FLEXBundleShortcuts : FLEXShortcutsSection

@end

NS_ASSUME_NONNULL_END
